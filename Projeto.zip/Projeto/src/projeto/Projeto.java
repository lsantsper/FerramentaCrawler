package projeto;

import java.util.List;
import twitter4j.FilterQuery;
import twitter4j.GeoLocation;
import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.StallWarning;
import twitter4j.Status;
import twitter4j.StatusDeletionNotice;
import twitter4j.StatusListener;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.TwitterStream;
import twitter4j.TwitterStreamFactory;
import twitter4j.conf.ConfigurationBuilder;

/**
 *
 * @author larissafreitas
 */
public class Projeto {

    /**
     * @param args the command line arguments
     */
    private static final double LONGITUDE = -47.9292;
    private static final double LATITUDE = -15.7801;
    private static final String DATA_FINAL_BUSCA = "2016-07-06";
    private static final String DATA_INICIO_BUSCA = "2016-07-02";
    private static final String IDIOMA = "pt";
    private static final String TERMO_DE_BUSCA = "política";
    private static final int NUMERO_DE_TWEETS_POR_QUERY = 1000;

    public static void main(String[] args) {
        // TODO code application logic here

        ConfigurationBuilder cb = new ConfigurationBuilder();
        cb.setDebugEnabled(true)
                .setOAuthConsumerKey("efMJHQMjhPo1poL6192gVXX6s")
                .setOAuthConsumerSecret("1Fqbj3KnIs95rm2A9WKxi79aiEN4sqPAjLgQLppd6vtAKEX9VV")
                .setOAuthAccessToken("94545306-JUikSfRB4xjLD6VF2ZZL2fGu8sqi1WiewbqWLtJtX")
                .setOAuthAccessTokenSecret("VLldUors7FaYzCA0hcV72OyoofWcHPkk6pvJVPWxhSVDs");

        TwitterFactory tf = new TwitterFactory(cb.build());
        Twitter twitter = tf.getInstance();
        long total = 0;

        try {
            Query query = new Query(TERMO_DE_BUSCA);
            query.setGeoCode(new GeoLocation(LATITUDE, LONGITUDE), 3000, Query.KILOMETERS);
            query.setLang(IDIOMA);
            query.setSince(DATA_INICIO_BUSCA);
            query.setUntil(DATA_FINAL_BUSCA);
            query.count(NUMERO_DE_TWEETS_POR_QUERY);
            QueryResult result;
            long ultimo = -1;
            result = twitter.search(query);
            do {
                result = twitter.search(query);
                List<Status> tweets = result.getTweets();
                total += tweets.size();
                for (Status tweet : tweets) {
                    System.out.println("@" + tweet.getUser().getScreenName() + " - " + tweet.getText() + " - @" + tweet.getCreatedAt().toString());
                }
                ultimo = result.getMaxId();
                query.setSinceId(ultimo);
                System.out.println(ultimo);
            } while ((query = result.nextQuery()) != null);
        } catch (TwitterException te) {
            te.printStackTrace();
            System.out.println("Failed to search tweets: " + te.getMessage());
        } catch (NullPointerException e) {
            e.printStackTrace();
            System.out.println(e.getLocalizedMessage());
        } finally {
            System.out.println("Total de tweets recuperados:" + total);

        }

//        TwitterStream twitterStream = new TwitterStreamFactory(cb.build())
//                .getInstance();
//        StatusListener listener = new StatusListener() {
//
//            @Override
//            public void onStatus(Status status) {
//                //here you do whatever you want with the tweet
//                System.out.println(status.getText());
//
//            }
//
//            @Override
//            public void onException(Exception ex) {
//                ex.printStackTrace();
//            }
//
//            @Override
//            public void onDeletionNotice(StatusDeletionNotice arg0) {
//                // TODO Auto-generated method stub
//
//            }
//
//            @Override
//            public void onScrubGeo(long arg0, long arg1) {
//
//            }
//
//            @Override
//            public void onStallWarning(StallWarning arg0) {
//                // TODO Auto-generated method stub
//                System.out.println(arg0);
//            }
//
//            @Override
//            public void onTrackLimitationNotice(int arg0) {
//                // TODO Auto-generated method stub
//                System.out.println(arg0);
//            }
//
//        };
//
//        twitterStream.addListener(listener);
//        FilterQuery filterQuery = new FilterQuery();
//        double[][] locations = {{-74, 40}, {-73, 41}}; //those are the boundary from New York City
//        filterQuery.locations(locations);
//        twitterStream.filter(filterQuery);
    }

}
